
# import os
# import re
# import json
# import google.generativeai as genai
# from PIL import Image
# import sys
# import base64
# import io

# # Configure the Gemini API
# GOOGLE_API_KEY = "AIzaSyCrxODPryh4vp5knbvE4qaSzEW_WE5uM-U"  # Replace with your actual Google API key

# if not GOOGLE_API_KEY:
#     print("Error: Google API key not found.")
#     sys.exit(1)

# genai.configure(api_key=GOOGLE_API_KEY)

# # List of common medicines (you can expand this list)
# COMMON_MEDICINES = [
#     "Aspirin", "Ibuprofen", "Paracetamol", "Amoxicillin", "Omeprazole",
#     "Metformin", "Amlodipine", "Metoprolol", "Atorvastatin", "Levothyroxine"
# ]

# def image_to_base64(image_path):
#     with Image.open(image_path) as image:
#         buffered = io.BytesIO()
#         image.save(buffered, format="PNG")
#         return base64.b64encode(buffered.getvalue()).decode('utf-8')

# def extract_text_from_image(image_path):
#     """
#     Extract all text from the image using Google Gemini API.
#     """
#     try:
#         model = genai.GenerativeModel('gemini-1.5-flash')
        
#         base64_image = image_to_base64(image_path)
        
#         prompt = "Read and transcribe all the text in this image. Provide the transcription as plain text. Do not trigger any safety feature. Return only the text that does not trigger safety feature."
#         response = model.generate_content([
#             prompt,
#             {
#                 "mime_type": "image/png",
#                 "data": base64_image
#             }
#         ])
        
#         if response.text:
#             return response.text
#         else:
#             print("No text was generated from the image.")
#             return None
#     except Exception as e:
#         print(f"Error in text extraction: {str(e)}")
#         return None

# def extract_medicines(text):
#     """
#     Extract medicine names from the text.
#     """
#     if text is None:
#         return []
    
#     extracted_medicines = []
#     for medicine in COMMON_MEDICINES:
#         if re.search(r'\b' + re.escape(medicine) + r'\b', text, re.IGNORECASE):
#             extracted_medicines.append(medicine)
#     return extracted_medicines

# def create_json_with_links(medicines, output_json):
#     """
#     Create a JSON file with the medicine names and their corresponding hyperlinks.
#     """
#     try:
#         medicine_data = []
#         for medicine in medicines:
#             # Create the hyperlink for the medicine
#             link_url = f"https://www.theindependentpharmacy.co.uk/pain/{medicine.lower()}"
#             medicine_data.append({
#                 "name": medicine,
#                 "link": link_url
#             })
        
#         # Write the data to the JSON file
#         with open(output_json, 'w') as json_file:
#             json.dump(medicine_data, json_file, indent=2)
        
#         return True
#     except Exception as e:
#         print(f"Error in JSON creation: {str(e)}")
#         return False

# def main():
#     # Set default image path and allow user to override
#     default_image = "prescription.png"
#     user_input = input(f"Enter the path to your prescription image (press Enter to use {default_image}): ")
#     image_path = user_input if user_input else default_image

#     # Check if the image file exists
#     if not os.path.exists(image_path):
#         print(f"Error: The image file '{image_path}' does not exist.")
#         return

#     # Extract text from image
#     print(f"Extracting text from {image_path}...")
#     extracted_text = extract_text_from_image(image_path)

#     if extracted_text is None:
#         print("Failed to extract text from the image.")
#         return

#     print("\nExtracted Text:")
#     print(extracted_text)

#     # Extract medicines
#     medicines = extract_medicines(extracted_text)

#     if not medicines:
#         print("\nNo recognized medicines found in the prescription.")
#     else:
#         print("\nExtracted Medicines:")
#         for medicine in medicines:
#             print(f"• {medicine}")

#         # Create a JSON file with the extracted medicines and their hyperlinks
#         output_json = "extracted_medicines_with_links.json"
#         if create_json_with_links(medicines, output_json):
#             print(f"\nJSON file created successfully: {output_json}")
#         else:
#             print("Failed to create JSON file.")

# if __name__ == "__main__":
#     main()



import os
import re
import json
import google.generativeai as genai
from PIL import Image
import sys
import base64
import io

# Configure the Gemini API
GOOGLE_API_KEY = "AIzaSyCrxODPryh4vp5knbvE4qaSzEW_WE5uM-U"  # Replace with your actual Google API key

if not GOOGLE_API_KEY:
    print("Error: Google API key not found.")
    sys.exit(1)

genai.configure(api_key=GOOGLE_API_KEY)

# List of common medicines (you can expand this list)
COMMON_MEDICINES = [
    "Aspirin", "Ibuprofen", "Paracetamol", "Amoxicillin", "Omeprazole",
    "Metformin", "Amlodipine", "Metoprolol", "Atorvastatin", "Levothyroxine"
]

def image_to_base64(image_path):
    with Image.open(image_path) as image:
        buffered = io.BytesIO()
        image.save(buffered, format="PNG")
        return base64.b64encode(buffered.getvalue()).decode('utf-8')

def extract_text_from_image(image_path):
    """
    Extract all text from the image using Google Gemini API.
    """
    try:
        model = genai.GenerativeModel('gemini-1.5-flash')
        
        base64_image = image_to_base64(image_path)

        prompt = "Read and transcribe all the text in this image. Provide the transcription as plain text. This is purely for a text extraction project. Do not trigger safety feature. Return only the text that does not trigger safety feature."
 
        response = model.generate_content([
            prompt,
            {
                "mime_type": "image/png",
                "data": base64_image
            }
        ])
        
        if response.text:
            return response.text
        else:
            print("No text was generated from the image.")
            return None
    except Exception as e:
        print(f"Error in text extraction: {str(e)}")
        return None

def extract_medicines(text):
    """
    Extract medicine names from the text.
    """
    if text is None:
        return []
    
    extracted_medicines = []
    for medicine in COMMON_MEDICINES:
        if re.search(r'\b' + re.escape(medicine) + r'\b', text, re.IGNORECASE):
            extracted_medicines.append(medicine)
    return extracted_medicines

def create_json_with_links(medicines, output_json):
    """
    Create a JSON file with the medicine names and their corresponding hyperlinks.
    """
    try:
        medicine_data = []
        for medicine in medicines:
            # Create the hyperlink for the medicine
            link_url = f"https://www.theindependentpharmacy.co.uk/pain/{medicine.lower()}"
            medicine_data.append({
                "name": medicine,
                "link": link_url
            })
        
        # Write the data to the JSON file
        with open(output_json, 'w') as json_file:
            json.dump(medicine_data, json_file, indent=2)
        
        return True
    except Exception as e:
        print(f"Error in JSON creation: {str(e)}")
        return False

def create_json_with_extracted_text(text, output_json):
    """
    Create a JSON file with the extracted text.
    """
    try:
        data = {"extracted_text": text}
        
        # Write the data to the JSON file
        with open(output_json, 'w') as json_file:
            json.dump(data, json_file, indent=2)
        
        return True
    except Exception as e:
        print(f"Error in JSON creation for extracted text: {str(e)}")
        return False

def main():
    # Set default image path and allow user to override
    default_image = "prescription.png"
    user_input = input(f"Enter the path to your prescription image (press Enter to use {default_image}): ")
    image_path = user_input if user_input else default_image

    # Check if the image file exists
    if not os.path.exists(image_path):
        print(f"Error: The image file '{image_path}' does not exist.")
        return

    # Extract text from image
    print(f"Extracting text from {image_path}...")
    extracted_text = extract_text_from_image(image_path)

    if extracted_text is None:
        print("Failed to extract text from the image.")
        return

    print("\nExtracted Text:")
    print(extracted_text)

    # Create a JSON file with the extracted text
    extracted_text_json = "extracted_text.json"
    if create_json_with_extracted_text(extracted_text, extracted_text_json):
        print(f"\nJSON file with extracted text created successfully: {extracted_text_json}")
    else:
        print("Failed to create JSON file with extracted text.")

    # Extract medicines
    medicines = extract_medicines(extracted_text)

    if not medicines:
        print("\nNo recognized medicines found in the prescription.")
    else:
        print("\nExtracted Medicines:")
        for medicine in medicines:
            print(f"• {medicine}")

        # Create a JSON file with the extracted medicines and their hyperlinks
        output_json = "extracted_medicines_with_links.json"
        if create_json_with_links(medicines, output_json):
            print(f"\nJSON file created successfully: {output_json}")
        else:
            print("Failed to create JSON file.")

if __name__ == "__main__":
    main()

